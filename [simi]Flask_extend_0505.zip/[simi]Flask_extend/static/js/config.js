//front
var login_page = 'http://127.0.0.1:5500/templates/login.html'
var signup_page = 'http://127.0.0.1:5500/templates/signup.html'
var reset_page = 'http://127.0.0.1:5500/templates/reset.html'
var forget_page = 'http://127.0.0.1:5500/templates/forget-pass.html'

var index_page = 'http://127.0.0.1:5500/templates/index.html'
var kol_page = 'http://127.0.0.1:5500/templates/kol.html'
var outline_page = 'http://127.0.0.1:5500/templates/outline.html'


//back
var index_api = 'http://127.0.0.1:5000/protected'
var login_api = 'http://127.0.0.1:5000/login'
var signup_api = 'http://127.0.0.1:5000/signup'
var forget_api = 'http://127.0.0.1:5000/reset_password_request'
var reset_api = 'http://127.0.0.1:5000/reset_password'
var logout_api = 'http://127.0.0.1:5000/logout_with_cookies'