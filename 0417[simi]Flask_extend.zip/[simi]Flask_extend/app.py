import datetime
import logging
from threading import Thread
from datetime import timedelta, timezone
from flask import Flask, jsonify, request, render_template
from werkzeug.security import generate_password_hash, check_password_hash
from mongodb_utils import get_cached_mongo_db
from flask_socketio import SocketIO
from flask_mail import Mail, Message



from flask_jwt_extended import (
    unset_jwt_cookies, get_jwt_identity, jwt_required, JWTManager,
    current_user, set_access_cookies, create_access_token,
    create_refresh_token, decode_token
)
activity_db = get_cached_mongo_db()
records = activity_db['register']

app = Flask(__name__)
app.config.update(
    DEBUG=False,
    # EMAIL SETTINGS
    MAIL_SERVER='smtp.gmail.com',
    MAIL_PORT=465,
    MAIL_USE_SSL=True,
    MAIL_DEFAULT_SENDER=('admin', 'simi0203040506@gmail.com'),
    MAIL_MAX_EMAILS=10,
    MAIL_USERNAME='simi0203040506@gmail.com',
    MAIL_PASSWORD='simi0000'
)

app.config["JWT_SECRET_KEY"] = "kkkkkktest"
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=1)
app.config["JWT_REFRESH_TOKEN_EXPIRES"] = timedelta(days=30)
socketio = SocketIO(app, cors_allowed_origins='*')
jwt = JWTManager(app)
mail = Mail(app)
mail.init_app(app)


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s : %(message)s',
    filename='log/app.log')

@app.route('/signup', methods=['POST'])
def signup():
    try:
        data = request.get_json()
        hashed_password = generate_password_hash(data['password'], method='sha256')

        if records.find_one({'username': data['username']}):
            return jsonify({'message' : 'Username has been already created!'}), 401
        elif records.find_one({'email': data['email']}):
            return jsonify({'message' : 'Email has been already created!'}), 401
        else:
            new_user = {"username": data['username'], 'email': data['email'], 'password':hashed_password}
            records.insert_one(new_user)
            return jsonify({'message' : 'New user created!'}), 200
    except Exception as e:
        logging.exception(e)    
    
    return jsonify({'massage':"Please signup!"})

@app.route("/login", methods=["POST", "GET"])
def login():
    try:
        if request.method == "POST":
            auth = request.authorization

            if not auth or not auth.username or not auth.password:
                return jsonify({"msg": "Login required!"}), 401

            db_user = records.find_one({'username':auth.username})
            if not db_user:
                return jsonify({"msg": "Login required!"}), 401

            if check_password_hash(db_user['password'], auth.password):
                access_token = create_access_token(identity=auth.username)
                refresh_token = create_refresh_token(identity=auth.username)
                set_access_cookies(jsonify({"msg": "login successful"}), access_token)
                return jsonify({"msg": "login successful", 'access_token':access_token, 'refresh_token':refresh_token}), 200
    except Exception as e:
        logging.exception(e)

@app.route("/refresh", methods=["POST"])
@jwt_required(refresh=True)
def refresh():
    try:
        identity = get_jwt_identity()
        access_token = create_access_token(identity=identity)
        return jsonify(access_token=access_token), 200
    except Exception as e:
        logging.exception(e)

@app.route("/protected", methods=["GET"])
@jwt_required()
def protected():
    try:
        current_identity = get_jwt_identity()
        if current_identity:
            return jsonify(logged_in_as=current_identity), 200
        else:
            return jsonify(logged_in_as="please login"), 403
    except Exception as e:
        logging.exception(e)

@app.route("/logout_with_cookies", methods=["POST"])
@jwt_required()
def logout_with_cookies():
    try:
        current_identity = get_jwt_identity()
        response = jsonify({"msg": "logout successful {user}".format(user=current_identity)})
        unset_jwt_cookies(response)
        return response, 200
    except Exception as e:
        logging.exception(e) 

@app.route("/message")
def email_test_2():
    #  主旨
    msg_title = 'Hello It is Flask-Mail'
    #  寄件者，若參數有設置就不需再另外設置
    msg_sender = 'Sender Mail@mail_domain.com'
    #  收件者，格式為list，否則報錯
    msg_recipients = ['Recipients@mail_domain.com']
    #  郵件內容
    msg_body = 'Hey, I am mail body!'
    # 也可以利用html做內容
    msg_html = '<h1>Hey,Flask-mail Can Use HTML, and I Use thread</h1>'
    msg = Message(msg_title,
                  sender=msg_sender,
                  recipients=msg_recipients)
    msg.body = msg_body
    msg.html = msg_html

    #  使用多線程
    thr = Thread(target=send_async_email, args=[app, msg])
    thr.start()
    return 'You Send Mail by Flask-Mail Success!!'

def send_async_email(app, msg):
    with app.app_context():
        mail.send(msg)


@app.route("/reset_password_request", methods=['POST'])
def email_test():
    url = request.host_url + 'reset/'
    try:
        body = request.get_json()
        email = body.get('email')
        if not email:
            return jsonify({'message' : 'Email is empty!'}), 200
        db_user = records.find_one({'email':email})
        if not db_user:
            return jsonify({'message' : 'Email is invaild!'}), 200

        expires = datetime.timedelta(hours=24)
        reset_token = create_access_token(str(db_user['username']), expires_delta=expires)
        logging.info(reset_token)

        msg_title = '[Simi] Reset Your Password'
        msg_sender = 'simi0203040506@gmail.com'
        #  收件者，格式為list，否則報錯
        msg_recipients = [db_user['email']]
        msg_html = '''<h1>嘿!點擊連結，重新設定密碼！</h1>
                        <a href="{url_}">click</a>'''.format(url_=str(url + reset_token))
        logging.info(msg_html)
        msg = Message(msg_title,
                    sender=msg_sender,
                    recipients=msg_recipients)
        msg.html = msg_html
        thr = Thread(target=send_async_email, args=[app, msg])
        thr.start()
        return jsonify(msg="success send email"), 200
    except Exception as e:
        logging.exception(e)
    return jsonify(msg="fail to send email"), 200
        
@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    url = request.host_url + 'reset/'
    try:
        body = request.get_json()
        reset_token = body.get('reset_token')
        password = body.get('password')
        repeat_password = body.get('repeat_password')

        if password != repeat_password:
            return jsonify({'message' : 'password is not same!'}), 200

        if not reset_token:
            return jsonify({'message' : 'token invaild!'}), 200

        if not password or not password:
             return jsonify({'message' : 'password empty!'}), 200

        username = decode_token(reset_token)['sub']

        db_user = records.find_one({'username':username})
        hashed_password = generate_password_hash(password, method='sha256')
        
        new_data = {'password': hashed_password}
        records.update_one({'username': username}, {'$set': new_data}, upsert=True)

        msg_title = '[Simi] Password reset successful'
        msg_sender = 'simi0203040506@gmail.com'
        #  收件者，格式為list，否則報錯
        msg_recipients = [db_user['email']]
        msg_html = '''<h1>Password reset was successful</h1>'''
        msg = Message(msg_title,
                    sender=msg_sender,
                    recipients=msg_recipients)
        msg.html = msg_html
        #  使用多線程
        thr = Thread(target=send_async_email, args=[app, msg])
        thr.start()

        return jsonify(msg="success send email"), 200
    except Exception as e:
        logging.exception(e)
    return jsonify(msg="fail to send email"), 200
 
    # if current_user.is_authenticated:
    #     return redirect(url_for('index'))
    # user = User.verify_reset_password_token(token)
    # if not user:
    #     return redirect(url_for('index'))
    # form = ResetPasswordForm()
    # if form.validate_on_submit():
    #     user.set_password(form.password.data)
    #     db.session.commit()
    #     flash('Your password has been reset.')
    #     return redirect(url_for('login'))
    # return render_template('reset_password.html', form=form)

if __name__ == "__main__":
    app.run()
